

  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
  import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-auth.js";


  const firebaseConfig = {
    apiKey: "AIzaSyB_aWQHru3n7BWoHTYu1529PW-fPy_vuhg",
    authDomain: "doms-sti.firebaseapp.com",
    projectId: "doms-sti",
    storageBucket: "doms-sti.appspot.com",
    messagingSenderId: "810824568476",
    appId: "1:810824568476:web:95ea8ee1bf98ad974fa759",
    measurementId: "G-CE6XN4R0NL"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app);

  const login = document.getElementById('signin');
  login.addEventListener("click", function(event){
    event.preventDefault()

  const username = document.getElementById('studentusername').value;
  const password = document.getElementById('password').value;
   
  signInWithEmailAndPassword(auth, username, password)
  .then((userCredential) => {
    
    const user = userCredential.user;
    alert("Logging in...")

  })
  .catch((error) =>{
    const errorCode = error.code;
    const errorMessage = error.message;
    alert(errorMessage)
  })

})

  
